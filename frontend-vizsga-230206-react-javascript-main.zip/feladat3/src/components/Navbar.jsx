import * as React from "react";

export const Navbar = () => {

    return (
        <nav className="navbar navbar-expand-lg bg-body-tertiary">
            <div className="container-fluid">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <a className="nav-link active" aria-current="page" href="/">Főmenü</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="/scifi">Scifi</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="/humor">Humor</a>
                        </li>
                    </ul>

            </div>
        </nav>
    )
};