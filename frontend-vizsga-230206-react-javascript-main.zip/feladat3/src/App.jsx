import {BrowserRouter, Route, Routes} from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import {Fooldal} from "./pages/Fooldal.jsx"
import {Scifi} from "./pages/Scifi"
import {Humor} from "./pages/Humor"
import {Navbar} from "./components/Navbar.jsx";
import './App.css'

function App() {

    return (
            <BrowserRouter>
                <div className='app'>
                    <Navbar/>
                    <Routes>
                        <Route path='/' element={<Fooldal/>}/>
                        <Route path='/scifi' element={<Scifi/>}/>
                        <Route path='/humor' element={<Humor/>}/>
                    </Routes>
                </div>
            </BrowserRouter>
    )
}
export default App