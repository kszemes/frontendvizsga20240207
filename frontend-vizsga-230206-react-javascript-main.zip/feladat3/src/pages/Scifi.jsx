import React from 'react';
import './Scifi.css'
export const Scifi = () => {
    return (
        <div className='container text-center'>
            <h1>Sci-fi</h1>
            <ul>
                <li>Én, a robot</li>
                <li>Alapítvány</li>
                <li>Alapítvány és Birodalom</li>
                <li>Második Alapítvány</li>
                <li>Az Alapítvány pereme</li>
                <li>Alapítvány és Föld</li>
                <li>Az Alapítvány előtt</li>
            </ul>
        </div>
    );
};
