import React from 'react';

export const Humor = () => {
    return (
        <div className='container-fluid text-center'>
            <h1>Humor</h1>
            <table className="table table-bordered">
                <thead className='table-info'>
                <tr>
                    <th scope="col">Cím</th>
                    <th scope="col">Szerző</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>Galaxis útikalauz stopposoknak</td>
                    <td>Douglas Adams</td>
                </tr>
                <tr>
                    <td>Mort, A Halál kisinasa</td>
                    <td>Terry Pratchett</td>
                </tr>
                <tr>
                    <td>Vadkanapó</td>
                    <td>Terry Pratchett</td>
                </tr>
                </tbody>
            </table>
        </div>
    )
        ;
};
