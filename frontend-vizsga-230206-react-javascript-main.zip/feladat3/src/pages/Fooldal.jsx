import React from 'react';

export const Fooldal = () => {
    return (
        <>
            <div className='container'></div>
            <h1 className='text-center'>Főoldal</h1>
            <p className='m-5 text-center'>Üdvözöljük a honlapunkon! Válasszon a menüsorból hogy megtekintse az akutálisan kiállított könyveket!</p>
        </>
    );
};