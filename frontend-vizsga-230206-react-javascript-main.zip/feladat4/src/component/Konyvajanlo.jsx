import * as React from "react";

export const Konyvajanlo = ({nev, ar, akcio}) => {

    return (
        <div>
            <h3>{nev}</h3>
            <p>{ar} Ft</p>
            {(akcio == 'true') ? <div>Akciós</div> : <div>Nem akciós</div>}
        </div>
    )
};