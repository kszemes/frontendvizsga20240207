import {Konyvajanlo} from "./component/Konyvajanlo";

function App() {
  return (
    <div>
      <Konyvajanlo nev={"A Gyűrű Szövetsége"} ar={2500} akcio={false}/>
      <Konyvajanlo nev={"A Két torony"} ar={2000} akcio={false}/>
      <Konyvajanlo nev={"A Király visszatér"} ar={999} akcio={true}/>
    </div>
  );
}

export default App;
